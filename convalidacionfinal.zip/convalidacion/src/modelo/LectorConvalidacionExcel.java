/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;


import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import javax.swing.*;
import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.List;

public class LectorConvalidacionExcel {
    
      public static List<Object[]> leerMallaDesdeExcel(File archivo) {
    List<Object[]> lista = new ArrayList<>();

    try (FileInputStream fis = new FileInputStream(archivo);
         Workbook libro = new XSSFWorkbook(fis)) {

        Sheet hoja = libro.getSheetAt(0);

        for (int i = 1; i <= hoja.getLastRowNum(); i++) {
            Row fila = hoja.getRow(i);
            if (fila == null) continue;

            
            String codAnt = getString(fila.getCell(0));
            String nomAnt = getString(fila.getCell(1));
            int credAnt = getInt(fila.getCell(2));

            String codNew = getString(fila.getCell(3));
            String nomNew = getString(fila.getCell(4));
            int credNew = getInt(fila.getCell(5));

            if (codAnt.isEmpty() || codNew.isEmpty()) continue;

            lista.add(new Object[]{codAnt, nomAnt, credAnt, codNew, nomNew, credNew});
        }

    } catch (Exception e) {
        JOptionPane.showMessageDialog(null,
                "Error leyendo archivo de convalidación:\n" + e.getMessage(),
                "Error", JOptionPane.ERROR_MESSAGE);
    }

    return lista;
}

private static String getString(Cell cell) {
    if (cell == null) return "";
    return switch (cell.getCellType()) {
        case STRING -> cell.getStringCellValue().trim();
        case NUMERIC -> String.valueOf((int) cell.getNumericCellValue());
        default -> "";
    };
}

   private static int getInt(Cell cell) {
    if (cell == null) return 0;

    try {
        if (cell.getCellType() == CellType.NUMERIC) {
            return (int) cell.getNumericCellValue();
        } else if (cell.getCellType() == CellType.STRING) {
            String valor = cell.getStringCellValue().trim();
            if (valor.matches("\\d+")) {
                return Integer.parseInt(valor);
            } else {
                System.err.println("Celda con texto no numérico: \"" + valor + "\"");
            }
        } else if (cell.getCellType() == CellType.FORMULA) {
            return (int) cell.getNumericCellValue(); 
        }
    } catch (Exception e) {
        System.err.println("Error al leer celda como número: " + e.getMessage());
    }

    return 0;
}

       
}

