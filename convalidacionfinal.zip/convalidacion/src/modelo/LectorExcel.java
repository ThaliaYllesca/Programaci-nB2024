/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;


import java.io.File;
import java.io.FileInputStream;
import java.util.*;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class LectorExcel {
    
    public static String nombreAlumno = "";
    public static String codigoAlumno = "";
    public static String codigoCurricula = "";
    public static String especialidad = "";

   public List<Object[]> leerAlumnoDesdeExcel(File archivo) {
        List<Object[]> lista = new ArrayList<>();
        try (FileInputStream fis = new FileInputStream(archivo);
             Workbook wb = new XSSFWorkbook(fis)) {

            Sheet sheet = wb.getSheetAt(0);

            
            nombreAlumno = getCellValue(sheet.getRow(1).getCell(0)).trim(); 
            codigoAlumno = getCellValue(sheet.getRow(2).getCell(0)).trim(); 
            codigoCurricula = getCellValue(sheet.getRow(4).getCell(0)).trim(); 
            especialidad = getCellValue(sheet.getRow(6).getCell(0)).trim(); 

            
            for (int i = 10; i <= sheet.getLastRowNum(); i++) {
                Row fila = sheet.getRow(i);
                if (fila == null || fila.getCell(0) == null) continue;

                String codCurso = getCellValue(fila.getCell(0)).trim();
                if (codCurso.isEmpty() || codCurso.length() < 4 || codCurso.length() > 12) continue;

                String nombreCurso = getCellValue(fila.getCell(1)).trim();
                String notaStr = getCellValue(fila.getCell(6)).trim();
                String creditosStr = getCellValue(fila.getCell(7)).trim();

                if (notaStr.isEmpty() || creditosStr.isEmpty()) continue;

                try {
                    double nota = Double.parseDouble(notaStr);
                    int creditos = (int) Double.parseDouble(creditosStr);

                    lista.add(new Object[]{"", codCurso, nombreCurso, nota, creditos});
                } catch (NumberFormatException e) {
                    continue;
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return lista;
    }

    private String getCellValue(Cell cell) {
        if (cell == null) return "";
        return switch (cell.getCellType()) {
            case STRING -> cell.getStringCellValue();
            case NUMERIC -> DateUtil.isCellDateFormatted(cell)
                            ? cell.getDateCellValue().toString()
                            : String.valueOf((int) cell.getNumericCellValue());
            default -> "";
        };
    }

}