/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author Diana
 */
public class Datosresumen {
    
     private double creditosConvalidados;
    private double creditosPerdidos;
    private double creditosRequeridos;

   public Datosresumen(double perdidos, double requeridos, double convalidados) {
        this.creditosPerdidos = perdidos;
        this.creditosRequeridos = requeridos;
        this.creditosConvalidados = convalidados;
    }

    public double getCreditosConvalidados() {
        return creditosConvalidados;
    }

    public double getCreditosPerdidos() {
        return creditosPerdidos;
    }

    public double getCreditosRequeridos() {
        return creditosRequeridos;
    }

    public void setCreditosConvalidados(double creditosConvalidados) {
        this.creditosConvalidados = creditosConvalidados;
    }

    public void setCreditosPerdidos(double creditosPerdidos) {
        this.creditosPerdidos = creditosPerdidos;
    }

    public void setCreditosRequeridos(double creditosRequeridos) {
        this.creditosRequeridos = creditosRequeridos;
    }
    
}
