
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package util;

import java.awt.Color;
import java.awt.Font;
import javax.swing.*;

public class principal extends javax.swing.JFrame {

    private JDesktopPane contenedor;
  

    
    public principal() {
       
         initComponents(); 
         
    contenedor = jDesktopPane2;         
    contenedor.setBackground(Color.LIGHT_GRAY); 
    contenedor.setVisible(true);
    contenedor.repaint();
    contenedor.revalidate();
    
    setTitle("Sistema de Gestión Curricular - UNAS");
    setSize(640, 750);
    setLocationRelativeTo(null);
    setDefaultCloseOperation(EXIT_ON_CLOSE);

    JMenuBar barra = new JMenuBar();
    JMenu menu = new JMenu("Menú");

    JMenuItem itemAlumno       = new JMenuItem("Datos del Alumno");
    JMenuItem itemMalla        = new JMenuItem("Convalidación de Malla");
    JMenuItem itemConvalidados = new JMenuItem("Cursos Convalidados");

    itemAlumno.addActionListener(e -> abrirVentana(new DatosAlum()));
    itemMalla.addActionListener(e -> abrirVentana(new ConvalidacionMalla()));
    itemConvalidados.addActionListener(e -> abrirVentana(new CursosComvalidado()));

    menu.add(itemAlumno);
    menu.add(itemMalla);
    menu.add(itemConvalidados);
    barra.add(menu);

    setJMenuBar(barra);
}
 

  
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jMenu1 = new javax.swing.JMenu();
        jMenuItem1 = new javax.swing.JMenuItem();
        jMenuItem2 = new javax.swing.JMenuItem();
        jMenuItem4 = new javax.swing.JMenuItem();
        jCheckBoxMenuItem1 = new javax.swing.JCheckBoxMenuItem();
        jDesktopPane1 = new javax.swing.JDesktopPane();
        jInternalFrame1 = new javax.swing.JInternalFrame();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jSeparator3 = new javax.swing.JSeparator();
        jDesktopPane2 = new javax.swing.JDesktopPane();
        jSeparator2 = new javax.swing.JSeparator();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu2 = new javax.swing.JMenu();
        jMenu3 = new javax.swing.JMenu();
        jMenuItem3 = new javax.swing.JMenuItem();
        jMenuItem5 = new javax.swing.JMenuItem();
        jMenuItem6 = new javax.swing.JMenuItem();
        jMenu4 = new javax.swing.JMenu();
        jMenu6 = new javax.swing.JMenu();

        jMenu1.setText("jMenu1");

        jMenuItem1.setText("jMenuItem1");

        jMenuItem2.setText("jMenuItem2");

        jMenuItem4.setText("jMenuItem4");

        jCheckBoxMenuItem1.setSelected(true);
        jCheckBoxMenuItem1.setText("jCheckBoxMenuItem1");

        jDesktopPane1.setLayout(new java.awt.BorderLayout());

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new java.awt.CardLayout());

        jInternalFrame1.setBackground(new java.awt.Color(204, 204, 204));
        jInternalFrame1.setForeground(new java.awt.Color(204, 204, 204));
        jInternalFrame1.setVisible(true);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setLayout(null);

        jLabel1.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 102, 204));
        jLabel1.setText("Bienvenido!");
        jPanel1.add(jLabel1);
        jLabel1.setBounds(20, 10, 120, 17);

        jLabel2.setForeground(new java.awt.Color(153, 153, 153));
        jLabel2.setText("🏠/alumno/2025-1/Sistema de Gestion curricular  ");
        jPanel1.add(jLabel2);
        jLabel2.setBounds(10, 30, 300, 16);
        jPanel1.add(jLabel5);
        jLabel5.setBounds(0, -30, 240, 30);
        jPanel1.add(jSeparator3);
        jSeparator3.setBounds(0, 63, 630, 10);

        jDesktopPane2.add(jSeparator2);
        jSeparator2.setBounds(40, 600, 590, 20);

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/unass.png"))); // NOI18N
        jDesktopPane2.add(jLabel3);
        jLabel3.setBounds(140, 190, 340, 310);

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(0, 102, 204));
        jLabel4.setText("Dirección de Asuntos Académicos");
        jDesktopPane2.add(jLabel4);
        jLabel4.setBounds(30, 540, 210, 16);

        jLabel6.setText("Ⓒ 2000–2025 Área de Soporte Académico");
        jDesktopPane2.add(jLabel6);
        jLabel6.setBounds(20, 570, 230, 16);

        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(0, 153, 153));
        jLabel7.setText("Universidad Nacional Agraria de la Selva");
        jDesktopPane2.add(jLabel7);
        jLabel7.setBounds(360, 620, 250, 30);

        jLabel9.setText("Tingo Maria - Unas ");
        jDesktopPane2.add(jLabel9);
        jLabel9.setBounds(450, 660, 110, 16);

        jPanel1.add(jDesktopPane2);
        jDesktopPane2.setBounds(-10, -90, 640, 700);

        jInternalFrame1.getContentPane().add(jPanel1, java.awt.BorderLayout.CENTER);

        jMenu2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/student.png"))); // NOI18N
        jMenuBar1.add(jMenu2);

        jMenu3.setText("☰");

        jMenuItem3.setText("Record del alumno");
        jMenuItem3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem3ActionPerformed(evt);
            }
        });
        jMenu3.add(jMenuItem3);

        jMenuItem5.setText("Convalidacion de malla");
        jMenuItem5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem5ActionPerformed(evt);
            }
        });
        jMenu3.add(jMenuItem5);

        jMenuItem6.setText("cursos convalidados ");
        jMenuItem6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem6ActionPerformed(evt);
            }
        });
        jMenu3.add(jMenuItem6);

        jMenuBar1.add(jMenu3);

        jMenu4.setText("                                                                                                       🏠 🔔    2025-1  🚩");
        jMenuBar1.add(jMenu4);

        jMenu6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/imag.png"))); // NOI18N
        jMenuBar1.add(jMenu6);

        jInternalFrame1.setJMenuBar(jMenuBar1);

        getContentPane().add(jInternalFrame1, "card2");

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jMenuItem6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem6ActionPerformed

        CursosComvalidado com = new CursosComvalidado();
        contenedor.add(com);
        com.setVisible(true);
    }//GEN-LAST:event_jMenuItem6ActionPerformed

    private void jMenuItem5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem5ActionPerformed
                     
      abrirVentana(new ConvalidacionMalla());
  
               
    }//GEN-LAST:event_jMenuItem5ActionPerformed

    private void jMenuItem3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem3ActionPerformed

           DatosAlum ventana = new DatosAlum();
    abrirVentana(ventana);
    }//GEN-LAST:event_jMenuItem3ActionPerformed
private void abrirVentana(JInternalFrame ventana) {

    contenedor.add(ventana);
    ventana.setVisible(true);
    try {
        ventana.setMaximum(true);
    } catch (Exception e) {
        e.printStackTrace();
    }
}
  
     public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new principal().setVisible(true);
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JCheckBoxMenuItem jCheckBoxMenuItem1;
    private javax.swing.JDesktopPane jDesktopPane1;
    private javax.swing.JDesktopPane jDesktopPane2;
    private javax.swing.JInternalFrame jInternalFrame1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenu jMenu3;
    private javax.swing.JMenu jMenu4;
    private javax.swing.JMenu jMenu6;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JMenuItem jMenuItem2;
    private javax.swing.JMenuItem jMenuItem3;
    private javax.swing.JMenuItem jMenuItem4;
    private javax.swing.JMenuItem jMenuItem5;
    private javax.swing.JMenuItem jMenuItem6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JSeparator jSeparator3;
    // End of variables declaration//GEN-END:variables
}
